package com.example.lab6_7;

public class User
{
    public static int moneyOfUser = 10000;
}

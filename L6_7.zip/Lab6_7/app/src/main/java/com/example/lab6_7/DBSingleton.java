package com.example.lab6_7;

import android.content.Context;

public class DBSingleton {
    private static DBSingleton ourInstance;

    public static DBSingleton getInstance(Context context) {
        if(ourInstance == null && context != null)
            ourInstance = new DBSingleton(context);
        return ourInstance;
    }

    private DBSingleton(Context context) {
        storeDatabaseAdapter = new StoreDatabaseAdapter(context.getApplicationContext());
        userDatabaseAdapter = new UserDatabaseAdapter(context.getApplicationContext());
    }

    private StoreDatabaseAdapter storeDatabaseAdapter;
    private UserDatabaseAdapter userDatabaseAdapter;

    public StoreDatabaseAdapter getStoreDatabaseAdapter() {
        return storeDatabaseAdapter;
    }

    public UserDatabaseAdapter getUserDatabaseAdapter() {
        return userDatabaseAdapter;
    }
}

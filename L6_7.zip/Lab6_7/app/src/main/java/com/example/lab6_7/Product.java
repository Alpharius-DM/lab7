package com.example.lab6_7;

import java.io.Serializable;

public class Product implements Serializable
{
    private long id;
    private String name;
    private int amount;
    private float price;
    private int status; // 0 - готов к продаже / изменению, 1 - недоступно из-за покупки, 2 - недоступно из-за изменения данных
    // 3 недоступно из-за покупки и товар из userdatabase ,  4 - новый продукт из BackEndActivity


    public Product(long id, String name, int amount, float price)
    {
        this(id, name, amount, price, 0);
    }
    public Product(long id, String name, int amount, float price, int status)
    {
        this.id = id;
        this.name = name;
        this.amount = amount;
        this.price = price;
        this.status = status;
    }

    public long getId()
    {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString()
    {
        return "Товар " + name + " по цене " + price + " в кол-ве " + amount;
    }
    public String toStringWithoutMoney()
    {
        return "Товар " + name + " в кол-ве " + amount;
    }

    @Override
    public boolean equals(Object obj)
    {
        Product pr = (Product)obj;
        return this.getAmount() == pr.getAmount() && this.getName().equals(pr.getName()) && this.getPrice() == pr.getPrice();
    }
}

package com.example.lab6_7;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class StoreDatabaseHelper extends SQLiteOpenHelper
{
    private static final String DATABASE_NAME = "store.db";
    private static final int SCHEMA = 1;
    static final String TABLE = "Goods";

    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME_OF_PRODUCT = "name";
    public static final String COLUMN_AMOUNT = "amount";
    public static final String COLUMN_PRICE = "price";
    public static final String COLUMN_STATUS = "status";

    public StoreDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, SCHEMA);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NAME_OF_PRODUCT + " TEXT, "
                + COLUMN_AMOUNT + " INTEGER, "
                + COLUMN_PRICE + " REAL, "
                + COLUMN_STATUS + " INTEGER);");

        db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME_OF_PRODUCT
                + ", " + COLUMN_AMOUNT + ", " + COLUMN_PRICE + ", " + COLUMN_STATUS  + ") " +
                "VALUES ('Кофе', 10, 60, 0), ('Компьютерная мышь', 15, 300, 0),('Коврик для мышки', 4, 160, 0),('Подушка', 8, 400, 0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }
}

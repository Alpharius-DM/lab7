package com.example.lab6_7;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.NotificationCompatSideChannelService;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;

public class PageFragment extends Fragment
{
    private Product product;
    private Product userProduct;
    private int goal;
    private boolean toastWas = false;
    private DelayTask delayTask;
    public static ArrayList<VerificationProductPurchase> verificationProducts = new ArrayList<>();
    public static PageFragment newInstance(Product product, int goal)
    {
        PageFragment fragment = new PageFragment();
        Bundle args=new Bundle();
        args.putSerializable("product", product);
        args.putInt("goal", goal);
        fragment.setArguments(args);
        return fragment;
    }

    public PageFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        product = getArguments() != null ? (Product) getArguments().getSerializable("product") : null;
        goal = getArguments() != null ? getArguments().getInt("goal") : 1;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View result = null;
        switch (goal)
        {
            case 0: //фрагмент для просмотра товаров на стороне клиента
            {
                result=inflater.inflate(R.layout.product_fragment_page, container, false);
                final TextView pageHeader=(TextView)result.findViewById(R.id.textInPage);
                Button button = (Button)result.findViewById(R.id.buttonInFragment);
                pageHeader.setText(product.toStringWithoutMoney());
                button.setVisibility(View.INVISIBLE);
                break;
            }
            case 1: //покупка товаров клиентом
            {
                result=inflater.inflate(R.layout.product_fragment_page, container, false);
                final TextView pageHeader=(TextView)result.findViewById(R.id.textInPage);
                Button button = (Button)result.findViewById(R.id.buttonInFragment);
                pageHeader.setText(product.toString());
                button.setText("Купить товар");
                button.setOnClickListener(new ViewPager.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        StoreDatabaseAdapter storeDatabaseAdapter = DBSingleton.getInstance(null).getStoreDatabaseAdapter();
                        UserDatabaseAdapter userDatabaseAdapter = DBSingleton.getInstance(null).getUserDatabaseAdapter();

                        if(product.getAmount() > 0)
                        {
                            for(int i = 0; i < verificationProducts.size(); i++)
                            {
                                if(verificationProducts.get(i).nameOfProduct.equals(product.getName()) &&
                                        !verificationProducts.get(i).isFirstPurchase)
                                {
                                    Toast.makeText(getContext(), "Данный товар был куплен, но транзакция прошла не полностью," +
                                            " подождите несколько секунд", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                            }
                            if(User.moneyOfUser >= product.getPrice())
                            {
                                storeDatabaseAdapter.open();
                                userDatabaseAdapter.open();

                                Product updatedProduct = storeDatabaseAdapter.getProduct(product.getId());

                                if(updatedProduct.getStatus() == 0 || updatedProduct.getStatus() == 1)
                                {
                                    if(updatedProduct.equals(product) || updatedProduct.getStatus() == 1)
                                    {
                                        ArrayList<Product> productsForTask = new ArrayList<>();

                                        if(updatedProduct.getStatus() == 0)
                                        {
                                            product.setStatus(1);
                                            storeDatabaseAdapter.update(product);
                                        }

                                        product.setAmount(product.getAmount() - 1);

                                        productsForTask.add(product);

                                        if(userProduct == null)
                                            userProduct = userDatabaseAdapter.getProduct(product.getName());

                                        if(userProduct != null)
                                        {
                                            userProduct.setStatus(3);
                                            userDatabaseAdapter.update(userProduct);

                                            userProduct.setAmount(userProduct.getAmount() + 1);
                                            productsForTask.add(userProduct);
                                            userDatabaseAdapter.update(userProduct);

                                        }
                                        else
                                        {
                                            Product productForInsert = new Product(-1, product.getName(),
                                                    1, product.getPrice(), 3);
                                            userDatabaseAdapter.insert(productForInsert);
                                            userProduct = userDatabaseAdapter.getProduct(productForInsert.getName());
                                            productsForTask.add(userProduct);
                                        }
                                        if(delayTask != null)
                                            delayTask.cancel(true);

                                        delayTask = new DelayTask(productsForTask);
                                        delayTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

                                        Log.d("Case 1", "Добавление продукта в верификацию " + product.getName());

                                        boolean isSameProductInVerification = false;
                                        for(int i = 0; i < verificationProducts.size(); i++)
                                        {
                                            if(verificationProducts.get(i).nameOfProduct.equals(product.getName()))
                                            {
                                                isSameProductInVerification = true;
                                                break;
                                            }
                                        }
                                        if (!isSameProductInVerification)
                                            verificationProducts.add(new VerificationProductPurchase(product.getName()));

                                        User.moneyOfUser -= product.getPrice();
                                        pageHeader.setText(product.toString());
                                    }
                                    else
                                    {
                                        Toast.makeText(getContext(), "Данный товар прошел редакцию, изменения данных обновлены, транзакция отменена",
                                                Toast.LENGTH_SHORT).show();
                                        product = updatedProduct;
                                        pageHeader.setText(product.toString());
                                    }
                                }
                                else if(!toastWas)
                                {
                                    Toast.makeText(getContext(), "Данный товар был недавно отредактирован, подождите несколько секунд",
                                            Toast.LENGTH_SHORT).show();
                                    toastWas = true;
                                }

                                storeDatabaseAdapter.close();
                                userDatabaseAdapter.close();
                            }
                            else
                            {
                                Toast.makeText(getContext(), "Недостаточно денег у пользователя",Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
                break;
            }
            case 2: //редактирование товаров
            {
                result = inflater.inflate(R.layout.product_fragment_page_for_edit_mode, container, false);
                final TextView pagetext = (TextView)result.findViewById(R.id.textInPage);
                pagetext.setText(product.toString());

                final EditText amountText = (EditText)result.findViewById(R.id.amountEditText);
                final EditText priceText = (EditText)result.findViewById(R.id.priceEditText);

                Button editButton = (Button)result.findViewById(R.id.buttonAddition);
                Button cancelBut = (Button)result.findViewById(R.id.buttonCancel);

                editButton.setOnClickListener(new ViewPager.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        try
                        {
                            int amount = -1;
                            int price = -1;
                            if(amountText.getText().toString().length() > 0)
                            {
                                amount = Integer.parseInt(amountText.getText().toString());
                            }
                            if (priceText.getText().toString().length() > 0)
                            {
                                price = Integer.parseInt(priceText.getText().toString());
                            }
                            StoreDatabaseAdapter storeDatabaseAdapter = DBSingleton.getInstance(null).getStoreDatabaseAdapter();
                            storeDatabaseAdapter.open();

                            Product updatedProduct = storeDatabaseAdapter.getProduct(product.getId());

                            if(updatedProduct.getStatus() == 0 || updatedProduct.getStatus() == 2)
                            {
                                if(updatedProduct.equals(product) || updatedProduct.getStatus() == 2)
                                {
                                    if(updatedProduct.getStatus() == 0)
                                    {
                                        product.setStatus(2);
                                        storeDatabaseAdapter.update(product);
                                    }

                                    if(amount >= 0)
                                        product.setAmount(amount);
                                    if(price > 5)
                                        product.setPrice(price);
                                    else if(price != -1)
                                        Toast.makeText(getContext(), "Цена должна быть больше 5",Toast.LENGTH_SHORT).show();


                                    ArrayList<Product> products = new ArrayList<>();
                                    products.add(product);
                                    if(delayTask != null)
                                        delayTask.cancel(true);

                                    delayTask = new DelayTask(products);
                                    delayTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

                                    pagetext.setText(product.toString());
                                }
                                else
                                {
                                    Toast.makeText(getContext(), "Данный товар прошел операцию покупки, изменения данных обновлены, редакция отменена",
                                            Toast.LENGTH_SHORT).show();
                                    product = updatedProduct;
                                    pagetext.setText(product.toString());
                                }
                            }
                            else if(!toastWas)
                            {
                                Toast.makeText(getContext(), "Данный товар был недавно отредактирован, подождите несколько секунд",
                                        Toast.LENGTH_SHORT).show();
                                toastWas = true;
                            }

                            storeDatabaseAdapter.close();
                        }
                        catch (Exception ex)
                        {
                            Toast.makeText(getContext(), "Неверные данные",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                cancelBut.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        amountText.setText("");
                        priceText.setText("");
                    }
                });
                break;
            }

        }

        return result;
    }
}

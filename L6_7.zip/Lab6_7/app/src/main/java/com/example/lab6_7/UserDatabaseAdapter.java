package com.example.lab6_7;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class UserDatabaseAdapter
{
    private UserDatabaseHelper dbHelper;
    private SQLiteDatabase database;

    public UserDatabaseAdapter(Context context){
        dbHelper = new UserDatabaseHelper(context.getApplicationContext());
    }

    public UserDatabaseAdapter open(){
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        dbHelper.close();
    }

    public void clearDB()
    {
        dbHelper.onUpgrade(database, 1,1);
    }

    private Cursor getAllEntries(){
        String[] columns = new String[] {UserDatabaseHelper.COLUMN_ID, UserDatabaseHelper.COLUMN_NAME_OF_PRODUCT,
                UserDatabaseHelper.COLUMN_AMOUNT, UserDatabaseHelper.COLUMN_PRICE, UserDatabaseHelper.COLUMN_STATUS};
        return  database.query(UserDatabaseHelper.TABLE, columns, null, null, null, null, null);
    }

    public List<Product> getProducts(){
        ArrayList<Product> products = new ArrayList<>();
        Cursor cursor = getAllEntries();
        if(cursor.moveToFirst()){
            do{
                int id = cursor.getInt(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_NAME_OF_PRODUCT));
                int amount = cursor.getInt(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_AMOUNT));
                float price = cursor.getFloat(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_PRICE));
                int status = cursor.getInt(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_STATUS));
                products.add(new Product(id, name, amount, price, status));
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        return products;
    }

    public long getCount(){
        return DatabaseUtils.queryNumEntries(database, UserDatabaseHelper.TABLE);
    }

    public Product getProduct(long id){
        Product product = null;
        String query = String.format("SELECT * FROM %s WHERE %s=?",UserDatabaseHelper.TABLE, UserDatabaseHelper.COLUMN_ID);
        Cursor cursor = database.rawQuery(query, new String[]{ String.valueOf(id)});
        if(cursor.moveToFirst()){
            String name = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_NAME_OF_PRODUCT));
            int amount = cursor.getInt(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_AMOUNT));
            float price = cursor.getFloat(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_PRICE));
            int status = cursor.getInt(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_STATUS));
            product = new Product(id, name, amount, price, status);
        }
        cursor.close();
        return  product;
    }
    public Product getProduct(String productName){
        Product product = null;
        String query = String.format("SELECT * FROM %s WHERE %s=?",UserDatabaseHelper.TABLE, UserDatabaseHelper.COLUMN_NAME_OF_PRODUCT);
        Cursor cursor = database.rawQuery(query, new String[]{ String.valueOf(productName)});
        if(cursor.moveToFirst()){
            int id = cursor.getInt(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_ID));
            int amount = cursor.getInt(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_AMOUNT));
            float price = cursor.getFloat(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_PRICE));
            int status = cursor.getInt(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_STATUS));
            product = new Product(id, productName, amount, price, status);
        }
        cursor.close();
        return  product;
    }

    public long insert(Product product){

        ContentValues cv = new ContentValues();
        cv.put(UserDatabaseHelper.COLUMN_NAME_OF_PRODUCT, product.getName());
        cv.put(UserDatabaseHelper.COLUMN_AMOUNT, product.getAmount());
        cv.put(UserDatabaseHelper.COLUMN_PRICE, product.getPrice());
        cv.put(UserDatabaseHelper.COLUMN_STATUS, product.getStatus());
        return  database.insert(UserDatabaseHelper.TABLE, null, cv);
    }

    public long delete(long productId){

        String whereClause = "_id = ?";
        String[] whereArgs = new String[]{String.valueOf(productId)};
        return database.delete(UserDatabaseHelper.TABLE, whereClause, whereArgs);
    }

    public long update(Product product){

        String whereClause = UserDatabaseHelper.COLUMN_ID + "=" + String.valueOf(product.getId());
        ContentValues cv = new ContentValues();
        cv.put(UserDatabaseHelper.COLUMN_NAME_OF_PRODUCT, product.getName());
        cv.put(UserDatabaseHelper.COLUMN_AMOUNT, product.getAmount());
        cv.put(UserDatabaseHelper.COLUMN_PRICE, product.getPrice());
        cv.put(UserDatabaseHelper.COLUMN_STATUS, product.getStatus());

        return database.update(UserDatabaseHelper.TABLE, cv, whereClause, null);
    }
    public long updateWithName(Product product){

        String whereClause = UserDatabaseHelper.COLUMN_NAME_OF_PRODUCT + "= '" + String.valueOf(product.getName()) + "'";
        ContentValues cv = new ContentValues();
        cv.put(UserDatabaseHelper.COLUMN_NAME_OF_PRODUCT, product.getName());
        cv.put(UserDatabaseHelper.COLUMN_AMOUNT, product.getAmount());
        cv.put(UserDatabaseHelper.COLUMN_PRICE, product.getPrice());
        cv.put(UserDatabaseHelper.COLUMN_STATUS, product.getStatus());
        return database.update(UserDatabaseHelper.TABLE, cv, whereClause, null);
    }
}

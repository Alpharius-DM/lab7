package com.example.lab6_7;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class PurchaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase);
        DBSingleton.getInstance(this).getStoreDatabaseAdapter().open();
        DBSingleton.getInstance(this).getUserDatabaseAdapter().open();

        ViewPager pager = (ViewPager)findViewById(R.id.purchase_pager);
        ArrayList<Product> products = (ArrayList<Product>) DBSingleton.getInstance(null).getStoreDatabaseAdapter().getProducts();
        ArrayList<Product> noEmptyProducts = new ArrayList<Product>();

        for (int i = 0; i < products.size(); i++)
        {
            if(products.get(i).getAmount() > 0 && products.get(i).getStatus() != 4)
                noEmptyProducts.add(products.get(i));
        }


        pager.setAdapter(new ViewPagerAdapter(getSupportFragmentManager(), noEmptyProducts ,1));
    }
    @Override
    public void onResume()
    {
        super.onResume();
        for (int i = 0; i < PageFragment.verificationProducts.size(); i++)
        {
            PageFragment.verificationProducts.get(i).isFirstPurchase = false;
        }
    }
    @Override
    public void onDestroy()
    {
        super.onDestroy();
        DBSingleton.getInstance(null).getStoreDatabaseAdapter().close();
        DBSingleton.getInstance(null).getUserDatabaseAdapter().close();
    }
}
